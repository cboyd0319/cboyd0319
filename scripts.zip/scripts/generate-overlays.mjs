import { fileURLToPath } from "node:url";
import { dirname, isAbsolute, join } from "node:path";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import sharp from "sharp";

import {
  OUTPUT_WIDTH as DEFAULT_OUTPUT_WIDTH,
  USERNAME,
} from "./lib/config.mjs";
import { github, githubParticipation } from "./lib/github.mjs";
import { loadFontAsDataUrl } from "./lib/font.mjs";
import { ownActiveRepos, renderRepositorySignSvg, renderToolchainSpectrumSvg } from "./lib/svg.mjs";
import { selectRepos } from "./lib/utils.mjs";
import { validateSignals } from "./validate-signals.mjs";

const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = join(SCRIPT_DIR, "..");
const ASSET_DIR = join(SCRIPT_DIR, "../assets");
const OUT_DIR = ASSET_DIR;
const GENERATED_DIR = join(ASSET_DIR, "generated");
const REFLECTION_DIR = join(ASSET_DIR, "sign_reflections");
const CONFIG_DIR = join(ROOT_DIR, "config");
const BACKGROUND = process.env.BACKGROUND?.trim() || "subway_blank_original.png";
const REPOS_PER_PAGE = 100;
const MAX_REPO_PAGES = 10;
const REPO_LIMIT = 4;
const SMOKE = process.argv.includes("--smoke");
const STATIC = ["1", "true", "yes"].includes(String(process.env.STATIC ?? "").toLowerCase());
const RASTERIZER = process.env.RASTERIZER?.trim() || "sharp";
const MIN_IMAGE_BYTES = 10_000;
const PANEL_RASTER_SCALE = 3;
const PANEL_SOFTEN_SIGMA = 0.025;
const PANEL_SHADOW_OPACITY = 0.06;
const PANEL_SHADOW_BLUR = 0.8;
const FINAL_WARM_WASH_ALPHA = 0;
const FINAL_FILM_GRAIN_OPACITY = 0;

function envNumber(name, fallback) {
  if (!process.env[name]?.trim()) return fallback;
  const value = Number(process.env[name]);
  return Number.isFinite(value) ? value : fallback;
}

function minutesAgo(minutes) {
  return new Date(Date.now() - minutes * 60_000).toISOString();
}

function daysAgo(days) {
  return new Date(Date.now() - days * 24 * 60 * 60_000).toISOString();
}

const OUTPUT_WIDTH = envNumber("OUTPUT_WIDTH", DEFAULT_OUTPUT_WIDTH);

async function readJson(path) {
  return JSON.parse(await readFile(path, "utf8"));
}

function relativeDate(value) {
  const text = String(value ?? "").trim().toLowerCase();
  const match = text.match(/^(\d+)(m|h|d|w|mo)\s+ago$/);
  if (!match) return new Date().toISOString();
  const amount = Number(match[1]);
  const unit = match[2];
  if (unit === "m") return minutesAgo(amount);
  if (unit === "h") return new Date(Date.now() - amount * 60 * 60_000).toISOString();
  if (unit === "d") return daysAgo(amount);
  if (unit === "w") return daysAgo(amount * 7);
  if (unit === "mo") return daysAgo(amount * 30);
  return new Date().toISOString();
}

function staticRepos(staticData) {
  return staticData.repos.map((repo) => ({
    name: repo.name,
    language: repo.language,
    language_pct: repo.language_pct,
    updated_label: repo.updated,
    pushed_at: relativeDate(repo.updated),
    stargazers_count: repo.stars,
    fork: false,
    archived: false,
  }));
}

function staticParticipation(repoName, staticData) {
  return staticData.repos.find((repo) => repo.name === repoName)?.sparkline ?? Array(10).fill(0);
}

function applyLayoutEnv(layout) {
  return {
    ...layout,
    board: {
      left: envNumber("BOARD_LEFT", layout.board.left),
      top: envNumber("BOARD_TOP", layout.board.top),
      width: envNumber("BOARD_WIDTH", layout.board.width),
      height: envNumber("BOARD_HEIGHT", layout.board.height),
    },
    toolchain: {
      left: envNumber("TOOLCHAIN_LEFT", layout.toolchain.left),
      top: envNumber("TOOLCHAIN_TOP", layout.toolchain.top),
      width: envNumber("TOOLCHAIN_WIDTH", layout.toolchain.width),
      height: envNumber("TOOLCHAIN_HEIGHT", layout.toolchain.height),
    },
  };
}

async function fetchOwnerRepos() {
  const repos = [];
  for (let page = 1; page <= MAX_REPO_PAGES; page++) {
    const chunk = await github(`/users/${USERNAME}/repos?type=owner&sort=pushed&direction=desc&per_page=${REPOS_PER_PAGE}&page=${page}`);
    if (!Array.isArray(chunk)) throw new Error("GitHub repos API returned an unexpected payload.");
    repos.push(...chunk);
    if (chunk.length < REPOS_PER_PAGE) return repos;
  }
  return repos;
}

async function collectData(staticData) {
  const allRepos = STATIC ? staticRepos(staticData) : await fetchOwnerRepos();
  const repos = selectRepos(ownActiveRepos(allRepos), REPO_LIMIT);
  const sparklines = STATIC
    ? repos.map((repo) => staticParticipation(repo.name, staticData))
    : await Promise.all(repos.map((repo) => githubParticipation(USERNAME, repo.name)));
  return { allRepos, repos, sparklines };
}

function scaledBox(box, scale) {
  return {
    left: Math.round(box.left * scale),
    top: Math.round(box.top * scale),
    width: Math.round(box.width * scale),
    height: Math.round(box.height * scale),
  };
}

async function validateImage(buffer, expectedWidth) {
  if (!buffer || buffer.byteLength < MIN_IMAGE_BYTES) {
    throw new Error("Generated signals.png is unexpectedly small.");
  }

  const metadata = await sharp(buffer).metadata();
  if (metadata.width !== expectedWidth || !metadata.height || metadata.height <= 0) {
    throw new Error(`Generated signals.png has unexpected dimensions: ${metadata.width}x${metadata.height}`);
  }
}

function panelGlassSvg(width, height) {
  return `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
<defs>
  <linearGradient id="panel-glass" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0%" stop-color="#ffffff" stop-opacity="0.13"/>
    <stop offset="20%" stop-color="#ffffff" stop-opacity="0.03"/>
    <stop offset="70%" stop-color="#1fc7e6" stop-opacity="0.015"/>
    <stop offset="100%" stop-color="#000000" stop-opacity="0.24"/>
  </linearGradient>
  <pattern id="panel-scan" width="1" height="4" patternUnits="userSpaceOnUse">
    <rect x="0" y="0" width="1" height="1" fill="#ffffff" opacity="0.2"/>
  </pattern>
  <filter id="panel-noise">
    <feTurbulence type="fractalNoise" baseFrequency="0.92" numOctaves="2" seed="19" result="noise"/>
    <feColorMatrix in="noise" type="saturate" values="0"/>
    <feComponentTransfer>
      <feFuncA type="table" tableValues="0 0.055"/>
    </feComponentTransfer>
  </filter>
</defs>
<rect width="${width}" height="${height}" rx="6" fill="#1fc7e6" opacity="0.006"/>
<rect width="${width}" height="${height}" rx="6" fill="url(#panel-glass)"/>
<rect width="${width}" height="${height}" fill="url(#panel-scan)" opacity="0.004"/>
<rect width="${width}" height="${height}" filter="url(#panel-noise)" opacity="0.006"/>
</svg>`;
}

async function rasterizePanelBase(svg, { width, height }) {
  if (RASTERIZER === "resvg") {
    const { Resvg } = await import("@resvg/resvg-js");
    const resvg = new Resvg(svg, {
      fitTo: {
        mode: "width",
        value: width,
      },
      font: {
        loadSystemFonts: true,
      },
    });
    return sharp(resvg.render().asPng())
      .resize(width, height, { fit: "fill", kernel: "lanczos3" })
      .ensureAlpha()
      .png()
      .toBuffer();
  }

  return sharp(Buffer.from(svg), { density: 72 * PANEL_RASTER_SCALE })
    .resize(width, height, { fit: "fill", kernel: "lanczos3" })
    .ensureAlpha()
    .png()
    .toBuffer();
}

async function renderPanelLayers(svg, { width, height, emissiveSvg = svg, shadowOpacity = PANEL_SHADOW_OPACITY, shadowBlur = PANEL_SHADOW_BLUR, panelSoftenSigma = PANEL_SOFTEN_SIGMA }) {
  const base = await rasterizePanelBase(svg, { width, height });
  const emissiveBase = await rasterizePanelBase(emissiveSvg, { width, height });

  const panel = await softenReadablePanel(base, panelSoftenSigma);

  const glow = await sharp(emissiveBase)
    .blur(0.8)
    .modulate({ brightness: 1.08, saturation: 1.08 })
    .png()
    .toBuffer();

  const glass = await sharp(Buffer.from(panelGlassSvg(width, height)))
    .png()
    .toBuffer();

  const shadow = await sharp({
    create: {
      width,
      height,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: shadowOpacity },
    },
  })
    .blur(shadowBlur)
    .png()
    .toBuffer();

  return { panel, glow, glass, shadow, emissive: emissiveBase };
}

async function softenReadablePanel(base, sigma = PANEL_SOFTEN_SIGMA) {
  if (sigma <= 0) return base;
  if (sigma < 0.3) {
    const blurred = await sharp(base).blur(0.3).png().toBuffer();
    return sharp(base)
      .composite([{ input: blurred, blend: "over", opacity: sigma / 0.3 }])
      .png()
      .toBuffer();
  }

  return sharp(base)
    .blur(sigma)
    .png()
    .toBuffer();
}

async function colorWash(width, height, background) {
  return sharp({
    create: {
      width,
      height,
      channels: 4,
      background,
    },
  })
    .png()
    .toBuffer();
}

function panelComposites(layers, box, { emissiveOpacity, panelOpacity, glassOpacity, wash }) {
  return [
    ...(layers.shadow ? [{
      input: layers.shadow,
      left: box.left,
      top: box.top,
      blend: "multiply",
    }] : []),
    {
      input: layers.glow,
      left: box.left,
      top: box.top,
      blend: "screen",
      opacity: emissiveOpacity,
    },
    {
      input: layers.panel,
      left: box.left,
      top: box.top,
      blend: "over",
      opacity: panelOpacity,
    },
    ...(glassOpacity > 0 ? [{
      input: layers.glass,
      left: box.left,
      top: box.top,
      blend: "screen",
      opacity: glassOpacity,
    }] : []),
    ...(wash ? [{
      input: wash,
      left: box.left,
      top: box.top,
      blend: "soft-light",
    }] : []),
  ];
}

async function optionalPng(path) {
  try {
    return await readFile(path);
  } catch (error) {
    if (error?.code === "ENOENT") return null;
    throw error;
  }
}

function finalFilmGrainSvg(width, height) {
  return `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
<filter id="final-grain">
  <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="31" result="noise"/>
  <feColorMatrix in="noise" type="saturate" values="0"/>
  <feComponentTransfer>
    <feFuncA type="table" tableValues="0 0.05"/>
  </feComponentTransfer>
</filter>
<rect width="${width}" height="${height}" filter="url(#final-grain)"/>
</svg>`;
}

async function applyFinalGrade(buffer, { width, height }) {
  if (FINAL_WARM_WASH_ALPHA <= 0 && FINAL_FILM_GRAIN_OPACITY <= 0) {
    return buffer;
  }

  const warmWash = await colorWash(width, height, {
    r: 255,
    g: 170,
    b: 95,
    alpha: FINAL_WARM_WASH_ALPHA,
  });
  const grain = Buffer.from(finalFilmGrainSvg(width, height));

  return sharp(buffer)
    .modulate({ brightness: 1.018, saturation: 0.985 })
    .composite([
      { input: warmWash, blend: "soft-light" },
      { input: grain, blend: "overlay", opacity: FINAL_FILM_GRAIN_OPACITY },
    ])
    .png()
    .toBuffer();
}

function expandedCrop(box, { width, height, pad = 16 }) {
  const left = Math.max(0, box.left - pad);
  const top = Math.max(0, box.top - pad);
  const right = Math.min(width, box.left + box.width + pad);
  const bottom = Math.min(height, box.top + box.height + pad);
  return {
    left,
    top,
    width: right - left,
    height: bottom - top,
  };
}

async function writeDebugCrops(output, { board, toolchain, width, height }) {
  const mainSign = expandedCrop(board, { width, height, pad: 18 });
  const toolSign = expandedCrop(toolchain, { width, height, pad: 12 });
  const mainCrop = await sharp(output).extract(mainSign).png().toBuffer();
  const toolCrop = await sharp(output).extract(toolSign).png().toBuffer();
  await Promise.all([
    writeFile(join(GENERATED_DIR, "debug-full.png"), output),
    writeFile(join(GENERATED_DIR, "debug-main-sign.png"), mainCrop),
    writeFile(join(GENERATED_DIR, "debug-toolchain.png"), toolCrop),
    writeFile(join(GENERATED_DIR, "debug-main-sign-2x.png"), await sharp(mainCrop).resize({ width: mainSign.width * 2 }).png().toBuffer()),
    writeFile(join(GENERATED_DIR, "debug-toolchain-2x.png"), await sharp(toolCrop).resize({ width: toolSign.width * 2 }).png().toBuffer()),
    writeFile(join(GENERATED_DIR, "debug-full-small.png"), await sharp(output).resize({ width: 640 }).png().toBuffer()),
  ]);
}

async function main() {
  const scene = await readJson(join(CONFIG_DIR, "scene.json"));
  const staticData = await readJson(join(CONFIG_DIR, "static-data.json"));
  const layout = applyLayoutEnv(await readJson(join(CONFIG_DIR, "layouts/subway-default.json")));
  const backgroundPath = isAbsolute(BACKGROUND) ? BACKGROUND : join(ASSET_DIR, BACKGROUND);
  const metadata = await sharp(backgroundPath).metadata();
  const sourceWidth = metadata.width || layout.sourceWidth;
  const sourceHeight = metadata.height || layout.sourceHeight;
  const scale = OUTPUT_WIDTH / sourceWidth;

  const { allRepos, repos, sparklines } = await collectData(staticData);
  if (SMOKE) {
    console.log(`Smoke OK - ${repos.length} repos, ${allRepos.length} total ${STATIC ? "static" : "fetched"}, ${sourceWidth}x${sourceHeight} background`);
    return;
  }

  const { css: fontCss } = await loadFontAsDataUrl();
  const board = scaledBox(layout.board, scale);
  const toolchain = scaledBox(layout.toolchain, scale);
  const repositorySvg = renderRepositorySignSvg({
    repos,
    allRepos,
    sparklines,
    summary: STATIC ? staticData.summary : null,
    fontCss,
    width: layout.board.width,
    height: layout.board.height,
    outputWidth: board.width,
    outputHeight: board.height,
  });
  const repositoryEmissiveSvg = renderRepositorySignSvg({
    repos,
    allRepos,
    sparklines,
    summary: STATIC ? staticData.summary : null,
    fontCss,
    width: layout.board.width,
    height: layout.board.height,
    outputWidth: board.width,
    outputHeight: board.height,
    emissiveOnly: true,
  });
  const toolchainSvg = renderToolchainSpectrumSvg({
    allRepos,
    fontCss,
    width: layout.toolchain.width,
    height: layout.toolchain.height,
    outputWidth: toolchain.width,
    outputHeight: toolchain.height,
  });
  const toolchainEmissiveSvg = renderToolchainSpectrumSvg({
    allRepos,
    fontCss,
    width: layout.toolchain.width,
    height: layout.toolchain.height,
    outputWidth: toolchain.width,
    outputHeight: toolchain.height,
    emissiveOnly: true,
  });
  const repositoryLayers = await renderPanelLayers(repositorySvg, {
    width: board.width,
    height: board.height,
    emissiveSvg: repositoryEmissiveSvg,
    panelSoftenSigma: 0.15,
  });
  const toolchainLayers = await renderPanelLayers(toolchainSvg, {
    width: toolchain.width,
    height: toolchain.height,
    emissiveSvg: toolchainEmissiveSvg,
    shadowOpacity: 0,
    panelSoftenSigma: 0.15,
  });
  const boardCyanWash = await colorWash(board.width, board.height, {
    r: 80,
    g: 170,
    b: 190,
    alpha: 0.004,
  });
  const toolAmberWash = await colorWash(toolchain.width, toolchain.height, {
    r: 240,
    g: 150,
    b: 85,
    alpha: 0.004,
  });
  const mainSignReflection = await optionalPng(join(REFLECTION_DIR, "main-sign-reflection.png"));
  const toolchainReflection = await optionalPng(join(REFLECTION_DIR, "toolchain-reflection.png"));

  const composited = await sharp(backgroundPath)
    .resize({ width: OUTPUT_WIDTH })
    .composite([
      ...panelComposites(repositoryLayers, board, {
        emissiveOpacity: 0.2,
        panelOpacity: 0.9,
        glassOpacity: 0.003,
        wash: boardCyanWash,
      }),
      ...(mainSignReflection ? [{
        input: mainSignReflection,
        left: board.left,
        top: board.top,
        blend: "screen",
        opacity: 0.06,
      }] : []),
      ...panelComposites(toolchainLayers, toolchain, {
        emissiveOpacity: 0.13,
        panelOpacity: 0.9,
        glassOpacity: 0,
        wash: null,
      }),
    ])
    .png()
    .toBuffer();
  const output = await applyFinalGrade(composited, {
    width: OUTPUT_WIDTH,
    height: Math.round(sourceHeight * scale),
  });

  await validateImage(output, OUTPUT_WIDTH);
  await validateSignals({
    scene,
    staticData,
    layout,
    repositorySvg,
    toolchainSvg,
    output,
    width: OUTPUT_WIDTH,
    height: Math.round(sourceHeight * scale),
  });
  await mkdir(OUT_DIR, { recursive: true });
  await mkdir(GENERATED_DIR, { recursive: true });
  await writeDebugCrops(output, {
    board,
    toolchain,
    width: OUTPUT_WIDTH,
    height: Math.round(sourceHeight * scale),
  });
  await Promise.all([
    writeFile(join(OUT_DIR, "signals.png"), output),
    writeFile(join(GENERATED_DIR, "repository-sign.svg"), repositorySvg),
    writeFile(join(GENERATED_DIR, "repository-sign-emissive.svg"), repositoryEmissiveSvg),
    writeFile(join(GENERATED_DIR, "toolchain-spectrum.svg"), toolchainSvg),
    writeFile(join(GENERATED_DIR, "toolchain-spectrum-emissive.svg"), toolchainEmissiveSvg),
    writeFile(join(GENERATED_DIR, "repository-sign.png"), repositoryLayers.panel),
    writeFile(join(GENERATED_DIR, "repository-sign-emissive.png"), repositoryLayers.emissive),
    writeFile(join(GENERATED_DIR, "repository-sign-glow.png"), repositoryLayers.glow),
    writeFile(join(GENERATED_DIR, "repository-sign-glass.png"), repositoryLayers.glass),
    writeFile(join(GENERATED_DIR, "toolchain-spectrum.png"), toolchainLayers.panel),
    writeFile(join(GENERATED_DIR, "toolchain-spectrum-emissive.png"), toolchainLayers.emissive),
    writeFile(join(GENERATED_DIR, "toolchain-spectrum-glow.png"), toolchainLayers.glow),
    writeFile(join(GENERATED_DIR, "toolchain-spectrum-glass.png"), toolchainLayers.glass),
  ]);
  console.log(`assets/signals.png written with ${repos.length} repo rows`);
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  await main();
}
