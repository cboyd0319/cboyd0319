import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { readFile } from "node:fs/promises";

import sharp from "sharp";

const ROOT_DIR = join(dirname(fileURLToPath(import.meta.url)), "..");

function fail(message) {
  throw new Error(`signals validation failed: ${message}`);
}

function requireIncludes(label, haystack, needles) {
  for (const needle of needles) {
    if (!haystack.includes(needle)) fail(`${label} missing ${needle}`);
  }
}

function sum(items) {
  return items.reduce((total, value) => total + Number(value || 0), 0);
}

export async function validateSignals({
  scene,
  staticData,
  layout,
  repositorySvg,
  toolchainSvg,
  output,
  width,
  height,
} = {}) {
  if (!scene) fail("scene config not loaded");
  if (!staticData?.repos?.length) fail("static repo data missing");
  if (!layout?.board || !layout?.toolchain) fail("layout boxes missing");

  requireIncludes("repository SVG", repositorySvg || "", [
    "REPOSITORY SIGNALS",
    "JobSentinel",
    "PyGuard",
    "WormsWMD-macOS-Fix",
    "PoshGuard",
    "65",
    "4",
    "3W",
  ]);
  requireIncludes("toolchain SVG", toolchainSvg || "", [
    "TOOLCHAIN",
    "TypeScript",
    "Python",
    "Shell",
    "PowerShell",
  ]);

  const languagePct = sum(staticData.repos.map((repo) => repo.language_pct));
  if (languagePct !== 100) fail(`toolchain percentages sum to ${languagePct}, expected 100`);

  const stars = sum(staticData.repos.map((repo) => repo.stars));
  if (stars !== Number(staticData.summary?.starsTotal)) {
    fail(`static stars total ${staticData.summary?.starsTotal} does not match repo sum ${stars}`);
  }
  if (staticData.repos.length !== Number(staticData.summary?.activeRepos)) {
    fail(`active repo summary ${staticData.summary?.activeRepos} does not match repo count ${staticData.repos.length}`);
  }
  if (!/^\d+W$/.test(String(staticData.summary?.streak || ""))) {
    fail(`streak malformed: ${staticData.summary?.streak}`);
  }

  const currentStation = String(scene.station?.name_en || "").toUpperCase();
  const nextStation = String(scene.direction?.next_en || "").toUpperCase();
  if (currentStation && nextStation && currentStation === nextStation) {
    fail(`current station and next station both ${currentStation}`);
  }
  if (scene.mode === "fictional_tokyo_inspired" && scene.operator?.show_real_tokyo_metro_branding) {
    fail("fictional mode cannot enable real Tokyo Metro branding");
  }
  if (!/^[A-Z]\d{2}$/.test(String(scene.station?.code || ""))) {
    fail(`station code must use line prefix plus two digits, got ${scene.station?.code}`);
  }
  if (/^\d+$/.test(String(scene.station?.code || ""))) {
    fail(`station code uses bare digits instead of line prefix: ${scene.station?.code}`);
  }
  if (scene.servicePanel?.items?.includes(scene.servicePanel?.title)) {
    fail(`service panel duplicates title ${scene.servicePanel.title} in items`);
  }
  const { bannedStrings = [], ...sceneWithoutBans } = scene;
  const serializedScene = JSON.stringify(sceneWithoutBans).toUpperCase();
  for (const banned of bannedStrings) {
    if (serializedScene.includes(String(banned).toUpperCase())) {
      fail(`scene config contains banned string ${banned}`);
    }
    if ((repositorySvg || "").toUpperCase().includes(String(banned).toUpperCase()) || (toolchainSvg || "").toUpperCase().includes(String(banned).toUpperCase())) {
      fail(`generated SVG contains banned string ${banned}`);
    }
  }

  for (const [name, box] of Object.entries({ board: layout.board, toolchain: layout.toolchain })) {
    if (box.left < 0 || box.top < 0 || box.width <= 0 || box.height <= 0) fail(`${name} layout has invalid dimensions`);
    if (box.left + box.width > layout.sourceWidth || box.top + box.height > layout.sourceHeight) {
      fail(`${name} layout exceeds source image bounds`);
    }
  }

  if (output) {
    const metadata = await sharp(output).metadata();
    if (metadata.width !== width || metadata.height !== height) {
      fail(`output dimensions ${metadata.width}x${metadata.height}, expected ${width}x${height}`);
    }
  }

  return true;
}

async function main() {
  const [scene, staticData, layout, repositorySvg, toolchainSvg, output] = await Promise.all([
    readFile(join(ROOT_DIR, "config/scene.json"), "utf8").then(JSON.parse),
    readFile(join(ROOT_DIR, "config/static-data.json"), "utf8").then(JSON.parse),
    readFile(join(ROOT_DIR, "config/layouts/subway-default.json"), "utf8").then(JSON.parse),
    readFile(join(ROOT_DIR, "assets/generated/repository-sign.svg"), "utf8"),
    readFile(join(ROOT_DIR, "assets/generated/toolchain-spectrum.svg"), "utf8"),
    readFile(join(ROOT_DIR, "assets/signals.png")),
  ]);
  await validateSignals({
    scene,
    staticData,
    layout,
    repositorySvg,
    toolchainSvg,
    output,
    width: layout.sourceWidth,
    height: layout.sourceHeight,
  });
  console.log("Signals validation OK");
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  await main();
}
